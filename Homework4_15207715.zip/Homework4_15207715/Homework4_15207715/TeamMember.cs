﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4_15207715
{
    public abstract class TeamMember
    {

        private double mAnnualSalary;
        private string mName;
        public TeamMember()
        {
            mAnnualSalary = 0.0;
            mName = "";
        }
        public TeamMember(double inAnnualSalary, string inName)
        {
            mAnnualSalary = inAnnualSalary;
            mName = inName;
        }

        public double AnnualSalary
        {
            get{return mAnnualSalary;}
            set{mAnnualSalary = value;}
        }

        public string Name
        {
            get{return mName;}
            set{mName = value;}
        }

        public virtual string Display()
        {
            return mName + " " + mAnnualSalary;
        }

        public abstract double GetContribution();


        public virtual string work() 
        {
            return "Contribution made=> ";
        }
    }
}
