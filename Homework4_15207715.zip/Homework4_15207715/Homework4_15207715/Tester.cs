﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4_15207715
{
    public class Tester:TeamMember
    {
        private bool mIsSadist;

        public Tester() : base()
        { }

        public Tester(double inAnnualSalary, string inName,bool inIsSadist) 
            : base(inAnnualSalary,inName)
        {
            mIsSadist = inIsSadist;
        }

        public bool IsSadist
        {
            get{return mIsSadist;}
            set{ mIsSadist = value;}
        }

        public override double GetContribution()
        {
            if (IsSadist==true)
            {
                return -25;
            }
            else
            {
                return 25;
            }
        }
        public override string work()
        {
            if (IsSadist==true)
            { 
                return base.work() + "strives to capture and destroy all joy";
            }
            else
            {
                return base.work() + "willing to work hard without inflicting pain or humiliation on others";
            }
        }
        public override string Display()
        {
            return base.Display();
        }
    }
}
