﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4_15207715
{
    public class WebApp:SoftwareProject
    {
        private int mNumTech;
        private string mURL;

        public WebApp():base()
        {}

        public WebApp(int inDuration, string inName, List<TeamMember> inTeam,int inNumTech,string inURL) 
            :base(inDuration,inName,inTeam)
        {
            mNumTech = inNumTech;
            mURL = inURL;
        }

        public int NumTech
        {
            get{return mNumTech;}
            set{mNumTech = value;}
        }

        public string URL
        {
            get{return mURL;}
            set{mURL = value;}
        }

        public override int calculateSuccess()
        {
            return 0 ;
        }

        public override string Display()
        {
            return base.Display() + " [WebApp" + " - www." + mURL + ".co.za]";
        }
    }
}
