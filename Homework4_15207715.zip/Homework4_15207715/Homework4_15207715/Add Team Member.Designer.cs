﻿namespace Homework4_15207715
{
    partial class Add_Team_Member
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxMemberType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxBusinessAnalyst = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtSalaryAnalyst = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNameAnalyst = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtWPM = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCertificationLevel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.gbxProgrammer = new System.Windows.Forms.GroupBox();
            this.cbxHyperTension = new System.Windows.Forms.ComboBox();
            this.txtSalaryPro = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNamePro = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Hypertension = new System.Windows.Forms.Label();
            this.txtBugRate = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.gbxTester = new System.Windows.Forms.GroupBox();
            this.cbxSaddist = new System.Windows.Forms.ComboBox();
            this.txtSalaryTester = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNameTester = new System.Windows.Forms.TextBox();
            this.Sadist = new System.Windows.Forms.Label();
            this.gbxBusinessAnalyst.SuspendLayout();
            this.gbxProgrammer.SuspendLayout();
            this.gbxTester.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbxMemberType
            // 
            this.cbxMemberType.FormattingEnabled = true;
            this.cbxMemberType.Items.AddRange(new object[] {
            "Business Analyst",
            "Programmer",
            "Tester"});
            this.cbxMemberType.Location = new System.Drawing.Point(452, 36);
            this.cbxMemberType.Name = "cbxMemberType";
            this.cbxMemberType.Size = new System.Drawing.Size(121, 21);
            this.cbxMemberType.TabIndex = 0;
            this.cbxMemberType.SelectionChangeCommitted += new System.EventHandler(this.cbxMemberType_SelectionChangeCommitted);
            this.cbxMemberType.SelectedValueChanged += new System.EventHandler(this.cbxMemberType_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(335, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Team Member Type:";
            // 
            // gbxBusinessAnalyst
            // 
            this.gbxBusinessAnalyst.Controls.Add(this.comboBox1);
            this.gbxBusinessAnalyst.Controls.Add(this.txtSalaryAnalyst);
            this.gbxBusinessAnalyst.Controls.Add(this.label9);
            this.gbxBusinessAnalyst.Controls.Add(this.txtNameAnalyst);
            this.gbxBusinessAnalyst.Controls.Add(this.label8);
            this.gbxBusinessAnalyst.Controls.Add(this.txtWPM);
            this.gbxBusinessAnalyst.Controls.Add(this.label5);
            this.gbxBusinessAnalyst.Controls.Add(this.label3);
            this.gbxBusinessAnalyst.Controls.Add(this.txtCertificationLevel);
            this.gbxBusinessAnalyst.Controls.Add(this.label2);
            this.gbxBusinessAnalyst.Location = new System.Drawing.Point(57, 79);
            this.gbxBusinessAnalyst.Name = "gbxBusinessAnalyst";
            this.gbxBusinessAnalyst.Size = new System.Drawing.Size(244, 180);
            this.gbxBusinessAnalyst.TabIndex = 2;
            this.gbxBusinessAnalyst.TabStop = false;
            this.gbxBusinessAnalyst.Text = "Business Analyst";
            this.gbxBusinessAnalyst.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.comboBox1.Location = new System.Drawing.Point(129, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 11;
            // 
            // txtSalaryAnalyst
            // 
            this.txtSalaryAnalyst.Location = new System.Drawing.Point(129, 139);
            this.txtSalaryAnalyst.Name = "txtSalaryAnalyst";
            this.txtSalaryAnalyst.Size = new System.Drawing.Size(100, 20);
            this.txtSalaryAnalyst.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Annual Salary:";
            // 
            // txtNameAnalyst
            // 
            this.txtNameAnalyst.Location = new System.Drawing.Point(129, 20);
            this.txtNameAnalyst.Name = "txtNameAnalyst";
            this.txtNameAnalyst.Size = new System.Drawing.Size(100, 20);
            this.txtNameAnalyst.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Name:";
            // 
            // txtWPM
            // 
            this.txtWPM.Location = new System.Drawing.Point(129, 107);
            this.txtWPM.Name = "txtWPM";
            this.txtWPM.Size = new System.Drawing.Size(100, 20);
            this.txtWPM.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Words Per Minute:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Loves system Architect:";
            // 
            // txtCertificationLevel
            // 
            this.txtCertificationLevel.Location = new System.Drawing.Point(129, 49);
            this.txtCertificationLevel.Name = "txtCertificationLevel";
            this.txtCertificationLevel.Size = new System.Drawing.Size(100, 20);
            this.txtCertificationLevel.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Certicification Level:";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(406, 294);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // gbxProgrammer
            // 
            this.gbxProgrammer.Controls.Add(this.cbxHyperTension);
            this.gbxProgrammer.Controls.Add(this.txtSalaryPro);
            this.gbxProgrammer.Controls.Add(this.label11);
            this.gbxProgrammer.Controls.Add(this.txtNamePro);
            this.gbxProgrammer.Controls.Add(this.label10);
            this.gbxProgrammer.Controls.Add(this.Hypertension);
            this.gbxProgrammer.Controls.Add(this.txtBugRate);
            this.gbxProgrammer.Controls.Add(this.label7);
            this.gbxProgrammer.Location = new System.Drawing.Point(329, 79);
            this.gbxProgrammer.Name = "gbxProgrammer";
            this.gbxProgrammer.Size = new System.Drawing.Size(244, 180);
            this.gbxProgrammer.TabIndex = 9;
            this.gbxProgrammer.TabStop = false;
            this.gbxProgrammer.Text = "Programmer";
            this.gbxProgrammer.Visible = false;
            // 
            // cbxHyperTension
            // 
            this.cbxHyperTension.FormattingEnabled = true;
            this.cbxHyperTension.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cbxHyperTension.Location = new System.Drawing.Point(129, 84);
            this.cbxHyperTension.Name = "cbxHyperTension";
            this.cbxHyperTension.Size = new System.Drawing.Size(100, 21);
            this.cbxHyperTension.TabIndex = 10;
            // 
            // txtSalaryPro
            // 
            this.txtSalaryPro.Location = new System.Drawing.Point(129, 114);
            this.txtSalaryPro.Name = "txtSalaryPro";
            this.txtSalaryPro.Size = new System.Drawing.Size(100, 20);
            this.txtSalaryPro.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Annual Salary:";
            // 
            // txtNamePro
            // 
            this.txtNamePro.Location = new System.Drawing.Point(129, 18);
            this.txtNamePro.Name = "txtNamePro";
            this.txtNamePro.Size = new System.Drawing.Size(100, 20);
            this.txtNamePro.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Name:";
            // 
            // Hypertension
            // 
            this.Hypertension.AutoSize = true;
            this.Hypertension.Location = new System.Drawing.Point(6, 84);
            this.Hypertension.Name = "Hypertension";
            this.Hypertension.Size = new System.Drawing.Size(72, 13);
            this.Hypertension.TabIndex = 5;
            this.Hypertension.Text = "Hypertension:";
            // 
            // txtBugRate
            // 
            this.txtBugRate.Location = new System.Drawing.Point(129, 50);
            this.txtBugRate.Name = "txtBugRate";
            this.txtBugRate.Size = new System.Drawing.Size(100, 20);
            this.txtBugRate.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Bug Rate:";
            // 
            // gbxTester
            // 
            this.gbxTester.Controls.Add(this.cbxSaddist);
            this.gbxTester.Controls.Add(this.txtSalaryTester);
            this.gbxTester.Controls.Add(this.label6);
            this.gbxTester.Controls.Add(this.label4);
            this.gbxTester.Controls.Add(this.txtNameTester);
            this.gbxTester.Controls.Add(this.Sadist);
            this.gbxTester.Location = new System.Drawing.Point(589, 79);
            this.gbxTester.Name = "gbxTester";
            this.gbxTester.Size = new System.Drawing.Size(244, 180);
            this.gbxTester.TabIndex = 11;
            this.gbxTester.TabStop = false;
            this.gbxTester.Text = "Tester";
            this.gbxTester.Visible = false;
            // 
            // cbxSaddist
            // 
            this.cbxSaddist.FormattingEnabled = true;
            this.cbxSaddist.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cbxSaddist.Location = new System.Drawing.Point(129, 78);
            this.cbxSaddist.Name = "cbxSaddist";
            this.cbxSaddist.Size = new System.Drawing.Size(100, 21);
            this.cbxSaddist.TabIndex = 9;
            // 
            // txtSalaryTester
            // 
            this.txtSalaryTester.Location = new System.Drawing.Point(129, 114);
            this.txtSalaryTester.Name = "txtSalaryTester";
            this.txtSalaryTester.Size = new System.Drawing.Size(100, 20);
            this.txtSalaryTester.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 117);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Annual Salary:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Name:";
            // 
            // txtNameTester
            // 
            this.txtNameTester.Location = new System.Drawing.Point(129, 36);
            this.txtNameTester.Name = "txtNameTester";
            this.txtNameTester.Size = new System.Drawing.Size(100, 20);
            this.txtNameTester.TabIndex = 5;
            // 
            // Sadist
            // 
            this.Sadist.AutoSize = true;
            this.Sadist.Location = new System.Drawing.Point(6, 78);
            this.Sadist.Name = "Sadist";
            this.Sadist.Size = new System.Drawing.Size(39, 13);
            this.Sadist.TabIndex = 3;
            this.Sadist.Text = "Sadist:";
            // 
            // Add_Team_Member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 339);
            this.Controls.Add(this.gbxTester);
            this.Controls.Add(this.gbxProgrammer);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gbxBusinessAnalyst);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbxMemberType);
            this.Name = "Add_Team_Member";
            this.Text = "Add_Team_Member";
            this.Load += new System.EventHandler(this.Add_Team_Member_Load_1);
            this.Click += new System.EventHandler(this.Add_Team_Member_Load);
            this.gbxBusinessAnalyst.ResumeLayout(false);
            this.gbxBusinessAnalyst.PerformLayout();
            this.gbxProgrammer.ResumeLayout(false);
            this.gbxProgrammer.PerformLayout();
            this.gbxTester.ResumeLayout(false);
            this.gbxTester.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxMemberType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbxBusinessAnalyst;
        private System.Windows.Forms.TextBox txtCertificationLevel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox gbxProgrammer;
        private System.Windows.Forms.Label Hypertension;
        private System.Windows.Forms.TextBox txtBugRate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtWPM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox gbxTester;
        private System.Windows.Forms.Label Sadist;
        private System.Windows.Forms.TextBox txtSalaryTester;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNameTester;
        private System.Windows.Forms.TextBox txtNameAnalyst;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSalaryAnalyst;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSalaryPro;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNamePro;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbxSaddist;
        private System.Windows.Forms.ComboBox cbxHyperTension;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}