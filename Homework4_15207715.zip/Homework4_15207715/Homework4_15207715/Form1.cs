﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Homework4_15207715
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SoftwareProjectList myProjectList;
        SoftwareProject myProject;
        WebApp webAppVar;
        DesktopApp desktopAppVar;
        MobileApp mobileAppVar;
        

        private void btnGenerateProject_Click(object sender, EventArgs e)
        {
            myProjectList = new SoftwareProjectList();
            SoftwareProject[] projectArrList = new SoftwareProject[3];
            projectArrList[0] = new DesktopApp();
            projectArrList[1] = new MobileApp();
            projectArrList[2] = new WebApp();
            //string saveURL;
            

            Random num = new Random();//for the projects
            Random numOfYears = new Random();//for the years
            Random prices = new Random();//for the prices
            Random trueOrFalse = new Random();//for the windows forms or not
            Random platforms = new Random();//for the platforms

            int rndNumber = num.Next(0,3);//projects 


            if (rndNumber==0)
            {//This class returns the DesktopApp project
                myProject = new SoftwareProject();
                myProject.Name = txtProjectName.Text;//for the name of the project
                myProject.Duration = numOfYears.Next(1, 10);//for the years

                desktopAppVar = new DesktopApp();
                desktopAppVar.Name = myProject.Name;
                desktopAppVar.Duration = myProject.Duration;
                desktopAppVar.WindowsBased = Convert.ToBoolean(trueOrFalse.Next(0, 2));
                myProjectList.Add(desktopAppVar);//Addded to the SoftwareProjectList
                lBoxProjects.Items.Add(desktopAppVar.Display());
            }
            else if(rndNumber==1)
            {//This class returns the MobileApp class
                myProject = new SoftwareProject();
                myProject.Name = txtProjectName.Text;//for the name of the project
                myProject.Duration = numOfYears.Next(1, 10);//for the years

                mobileAppVar = new MobileApp();
                mobileAppVar.Name = myProject.Name;
                mobileAppVar.Duration = myProject.Duration;
                mobileAppVar.Price = Convert.ToDouble(prices.Next(0, 1300000)/100);  
                mobileAppVar.NumPlatforms = platforms.Next(1,15);
                myProjectList.Add(mobileAppVar);//Addded to the SoftwareProjectList
                lBoxProjects.Items.Add(mobileAppVar.Display());
            }
            else if(rndNumber==2)
            {//This class returns the WebApp class
                myProject = new SoftwareProject();
                myProject.Name = txtProjectName.Text;//for the name of the project
                 myProject.Duration = numOfYears.Next(1, 10);//for the years
                webAppVar = new WebApp();

                webAppVar.Name = myProject.Name;
                webAppVar.Duration = myProject.Duration;
                var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                webAppVar.URL = new string(chars.Select(c => chars[num.Next(chars.Length)]).Take(8).ToArray());//generates the domain name
                myProjectList.Add(webAppVar);//Addded to the SoftwareProjectList
                lBoxProjects.Items.Add(webAppVar.Display());
            }

            //myProject = new SoftwareProject();
            //myProject.Name = txtProjectName.Text;//for the name of the project
            //myProject.Duration = numOfYears.Next(1, 10);//for the years

            //myProject.Name = txtProjectName.Text;
            //myProjectList.Add(projectArrList[rndNumber]);

        }



        private void button2_Click(object sender, EventArgs e)
        {
            //analystInstance = new BusinessAnalyst();
            //programmerInstance = new Programmer();
            //testerInstance = new Tester();

            Add_Team_Member myForm = new Add_Team_Member();
            myForm.ShowDialog();
            
            this.Refresh();
            lBoxTeam.Items.Add(myForm.TeamMembers.Display());
            this.Refresh();
        }
    }
}
