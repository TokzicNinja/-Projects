﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4_15207715
{
    public class MobileApp:SoftwareProject
    {
        private int mNumPlatforms;
        private double mPrice;

        public MobileApp():base()
        { }

        public MobileApp(int inDuration, string inName, List<TeamMember> inTeam,int inNumPlatform,double inPrice)
            :base(inDuration,inName,inTeam)
        {
            mNumPlatforms = inNumPlatform;
            mPrice = inPrice;
        }

        public int NumPlatforms
        {
            get{return mNumPlatforms;}
            set{ mNumPlatforms = value; }
        }

        public double Price
        {
            get{ return mPrice; }
            set{mPrice = value;}
        }

        public override int calculateSuccess()
        {
            return 0;
        }

        public override string Display()
        {
            if(mNumPlatforms>1)
            {
                return base.Display() + "[Mobile : Multiplatform @ "+mPrice.ToString("C") + "]";
            }
            else
            {
                return base.Display() + "[Mobile : Native @ " + mPrice.ToString("C") + "]";
            }
           
        }
    }
}
