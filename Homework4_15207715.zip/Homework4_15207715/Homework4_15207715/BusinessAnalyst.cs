﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4_15207715
{
    public class BusinessAnalyst : TeamMember
    {
        private int mCertificationLevel;
        private bool mLovesSystem;
        private int mWordsPerMinute;

        public BusinessAnalyst():base()
        {
        }

        public BusinessAnalyst(double inAnnualSalary, string inName, int inCertificationLevel, bool inLovesSystem, int inWordsPerMinute) 
            : base(inAnnualSalary, inName)
        {
            mCertificationLevel = inCertificationLevel;
            mLovesSystem = inLovesSystem;
            mWordsPerMinute = inWordsPerMinute;
        }

        public int CertificationLevel
        {
            get{return mCertificationLevel;}
            set{mCertificationLevel = value;}
        }

        public bool LovesSystem
        {
            get{return mLovesSystem;}
            set{mLovesSystem = value;}
        }

        public int WordsPerMinute
        {
            get{return mWordsPerMinute;}
            set{ mWordsPerMinute = value;}
        }

        public override double GetContribution()
        {
            if(mCertificationLevel>3)
            {
                return 100;
            }
            else if(mCertificationLevel==3)
            {
                return 75;
            }
            else if(mCertificationLevel==2)
            {
                return 50;
            }
            else if(mCertificationLevel==1)
            {
                return 25;
            }
            else
            {
                return 0;
            }

        }

        public override string work()
        {
            if (mLovesSystem==true)
            {
                return base.work() + "Loves system architect and a smashing analyst";
            }
            else
            {
                return base.work() + "Dislikes system architect and strives to work hard ";
            }
        }
        public override string Display()
        {
            return base.Display();
        }
    }
}
