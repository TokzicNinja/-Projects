﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework4_15207715
{
    public partial class Add_Team_Member : Form
    {
        public Add_Team_Member()
        {
            InitializeComponent();
        }



        private void Add_Team_Member_Load(object sender, EventArgs e)
        {
        }

        private void Add_Team_Member_Load_1(object sender, EventArgs e)
        {

        }

        private void cbxMemberType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            this.Refresh();
            if (cbxMemberType.Text == "Business Analyst")
            {
                this.Refresh();
                gbxBusinessAnalyst.Visible = true;
                gbxProgrammer.Visible = false;
                gbxTester.Visible = false;
                this.Refresh();
            }
            else if (cbxMemberType.Text == "Programmer")
            {
                this.Refresh();
                gbxProgrammer.Visible = true;
                gbxTester.Visible = false;
                gbxBusinessAnalyst.Visible = false;
                this.Refresh();
            }
            else if (cbxMemberType.Text == "Tester")
            {
                this.Refresh();
                gbxTester.Visible = true;
                gbxProgrammer.Visible = false;
                gbxBusinessAnalyst.Visible = false;
                this.Refresh();
            }
        }

        private void cbxMemberType_SelectedValueChanged(object sender, EventArgs e)
        {
            this.Refresh();
            if (cbxMemberType.Text == "Business Analyst")
            {
                this.Refresh();
                gbxBusinessAnalyst.Visible = true;
                gbxProgrammer.Visible = false;
                gbxTester.Visible = false;
                this.Refresh();
            }
            else if (cbxMemberType.Text == "Programmer")
            {
                this.Refresh();
                gbxProgrammer.Visible = true;
                gbxTester.Visible = false;
                gbxBusinessAnalyst.Visible = false;
                this.Refresh();
            }
            else if (cbxMemberType.Text == "Tester")
            {
                this.Refresh();
                gbxTester.Visible = true;
                gbxProgrammer.Visible = false;
                gbxBusinessAnalyst.Visible = false;
                this.Refresh();
            }
            else
            {
                this.Refresh();
                gbxTester.Visible = false;
                gbxProgrammer.Visible = false;
                gbxBusinessAnalyst.Visible = false;
                this.Refresh();

            }
        }

        BusinessAnalyst analystInfo;
        Programmer programmerInfo;
        Tester testerInfo;
        TeamMember teamMembers;
        SoftwareProject teams;

        private Add_Team_Member passVariable;
        public Add_Team_Member PassVariable
        {
            get { return passVariable; }
            //set { value = passVariable; }
        }

        public BusinessAnalyst AnalystInfo
        {
            get{return analystInfo;}
           //set{analystInfo = value;}
        }

        public Programmer ProgrammerInfo
        {
            get{return programmerInfo;}
            //set{programmerInfo = value;}
        }

        public Tester TesterInfo
        {
            get{return testerInfo;}
            //set {testerInfo = value;}
        }

        public SoftwareProject Teams
        {
            get{return teams;}
            set{teams = value;}
        }

        public TeamMember TeamMembers
        {
            get{return teamMembers;}
            //set{teamMembers = value;}
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.Refresh();

            if (cbxMemberType.Text == "Business Analyst")
            {//BUSINESS INFORMATION
                this.Refresh();
                analystInfo = new BusinessAnalyst();
                Teams = new SoftwareProject();
                Teams.Team = new List<TeamMember>();
                passVariable = new Add_Team_Member();
                passVariable.analystInfo = new BusinessAnalyst();
                teamMembers = new BusinessAnalyst();
                

                teamMembers.Name = passVariable.analystInfo.Name = analystInfo.Name = txtNameAnalyst.Text;
                passVariable.analystInfo.CertificationLevel = analystInfo.CertificationLevel = Convert.ToInt32(txtCertificationLevel.Text);
                
                if(cbxHyperTension.Text=="Yes")
                {
                    passVariable.analystInfo.LovesSystem = analystInfo.LovesSystem = true;
                }
                else if(cbxHyperTension.Text=="No")
                {
                    passVariable.analystInfo.LovesSystem = analystInfo.LovesSystem = false;
                }
                passVariable.analystInfo.WordsPerMinute = analystInfo.WordsPerMinute = Convert.ToInt32(txtWPM.Text);
                teamMembers.AnnualSalary = passVariable.analystInfo.AnnualSalary = analystInfo.AnnualSalary = Convert.ToDouble(txtSalaryAnalyst.Text);

                Teams.Team.Add(AnalystInfo);
                this.Refresh();
            }
            else if (cbxMemberType.Text == "Programmer")
            {//PROGRAMMER INFORMATION
                this.Refresh();
                programmerInfo = new Programmer();
                Teams = new SoftwareProject();
                Teams.Team = new List<TeamMember>();
                passVariable = new Add_Team_Member();
                passVariable.programmerInfo = new Programmer();
                teamMembers = new Programmer();

                teamMembers.Name = passVariable.programmerInfo.Name = programmerInfo.Name = txtNamePro.Text;
                programmerInfo.BugRate = Convert.ToInt32(txtBugRate.Text);

                if(cbxHyperTension.Text=="Yes")
                {
                     passVariable.programmerInfo.HyperTension = programmerInfo.HyperTension = true;
                }
                else if(cbxHyperTension.Text=="No")
                {
                    passVariable.programmerInfo.HyperTension = programmerInfo.HyperTension = false;
                }

                teamMembers.AnnualSalary = passVariable.programmerInfo.AnnualSalary = programmerInfo.AnnualSalary = Convert.ToDouble(txtSalaryPro.Text);
                
                Teams.Team.Add(programmerInfo);
                this.Refresh();
            }
            else if (cbxMemberType.Text == "Tester")
            { //TESTER INFORMATION
                this.Refresh();
                testerInfo = new Tester();
                Teams = new SoftwareProject();
                Teams.Team = new List<TeamMember>();
                passVariable = new Add_Team_Member();
                passVariable.testerInfo = new Tester();
                teamMembers = new Tester();

                teamMembers.Name = passVariable.testerInfo.Name = testerInfo.Name = txtNameTester.Text;

                if (cbxHyperTension.Text == "Yes")
                {
                    passVariable.testerInfo.IsSadist = testerInfo.IsSadist = true;
                }
                else if (cbxHyperTension.Text == "No")
                {
                    passVariable.testerInfo.IsSadist = testerInfo.IsSadist = false;
                }

                teamMembers.AnnualSalary = passVariable.testerInfo.AnnualSalary = testerInfo.AnnualSalary = Convert.ToDouble(txtSalaryTester.Text);

                Teams.Team.Add(testerInfo);
                this.Refresh();
            }

            this.Close();
        }
    }
}
