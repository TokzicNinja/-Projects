﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4_15207715
{
    public class Programmer:TeamMember
    {
        private double mBugRate;
        private bool mHyperTension;

        public Programmer() : base()
        { }

        public Programmer(double inAnnualSalary, string inName, double inBugRate, bool inHyperTension) 
            :base(inAnnualSalary, inName)
        {
            mBugRate = inBugRate;
            mHyperTension = inHyperTension;
        }

        public double BugRate
        {
            get{ return mBugRate; }
            set{mBugRate = value;}
        }

        public bool HyperTension
        {
            get{return mHyperTension;}
            set{mHyperTension = value;}
        }

        public override double GetContribution()
        {
            if(mBugRate>50 && mHyperTension==true)
            {
                return 25;
            }
            else if(mBugRate>50 && mHyperTension==false)
            {
                return 50;
            }
            else if(mBugRate<=50 && mHyperTension==true)
            {
                return 75;
            }
            else if(mBugRate<=50 && mHyperTension==false)
            {
                return 100;
            }
            else
            {
                return 0;
            }
        }

        public override string work()
        {
            if (mHyperTension==true)
            {
                return base.work() + "gets work done with an absolute high amount of blood pressure";
            }
            else
            {
                return base.work() + "procrastinator or average programmer, either way gets efficiently works thoroughly through the work";
            }
        }

        public override string Display()
        {
            return base.Display();
        }
    }
}
