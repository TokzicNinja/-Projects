﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Homework4_15207715
{
    public class SoftwareProject
    {
        private int mDuration;
        private string mName;
        private List<TeamMember> mTeam;

        public SoftwareProject()
        {
            mDuration = 0;
            mName = "";
            mTeam = null;
        }

        public SoftwareProject(int inDuration, string inName, List<TeamMember> inTeam)
        {
            mDuration = inDuration;
            mName = inName;
            mTeam = inTeam;
        }

        public int Duration
        {
            get{return mDuration;}
            set{mDuration = value;}
        }

        public string Name
        {
            get{return mName;}
            set{mName = value;}
        }

        public List<TeamMember> Team
        {
            get{return mTeam;}
            set{mTeam = value;}
        }


        public virtual int calculateSuccess()
        {
            return 0;
        }

        public virtual string Display()
        {
            return  mName+" ("+mDuration+" years) ";
        }

    }
}
