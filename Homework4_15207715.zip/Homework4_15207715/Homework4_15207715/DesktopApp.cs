﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework4_15207715
{
    public class DesktopApp:SoftwareProject
    {
        private bool mWindowsBased;

        public bool WindowsBased
        {
            get{return mWindowsBased;}
            set{mWindowsBased = value;}
        }

        public DesktopApp() : base()
        { }

        public DesktopApp(int inDuration, string inName, List<TeamMember> inTeam,bool inWindowsBased) 
            : base(inDuration, inName, inTeam)
        {
            mWindowsBased = inWindowsBased;
        }

        public override string Display()
        {
            if (mWindowsBased == Convert.ToBoolean(1))
            {
                return base.Display() + " [Desktop - " + "Other]";
            }
            else
            {
                return base.Display() + " [Desktop - " + "MicroSOFTY]";
            }
        }
    }
}
