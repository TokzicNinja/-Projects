﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTest1_u15207715
{
     public abstract class Animals
    {
        private string mName;
        private double mWeight;
        private int mAmountLegs;

        public Animals()
        {
            mName = "";
            mWeight = 0;
            mAmountLegs = 0;
        }
        public Animals(string inName, double inWeight, int inAmountLegs)
        {
            mName = inName;
            mWeight = inWeight;
            mAmountLegs = inAmountLegs;
        }

        public string Name
        {
            get
            {return mName;}
            set{mName = value;}
        }

        public double Weight
        {
            get{return mWeight;}
            set{mWeight = value;}
        }

        public int AmountLegs
        {
            get
            {return mAmountLegs;}
            set{mAmountLegs = value;}
        }

        public abstract string Talk();

        public virtual string DisplayInfo()
        {
            return mName + " " + mWeight + " " + mAmountLegs;
        }

    }
}
