﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassTest1_u15207715
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        AnimalList myList;
        private void button1_Click(object sender, EventArgs e)
        {
            myList = new AnimalList();
            Bird myBird = new Bird("Sparrow",12,2,54);
            myList.Add(myBird);
            LandAnimal myLandAnimal= new LandAnimal("Cheetah",21,4,60);
            myList.Add(myLandAnimal);

            foreach(Animals animalVar in myList )
            {
                MessageBox.Show(animalVar.Talk());
            }
        }
    }
}
