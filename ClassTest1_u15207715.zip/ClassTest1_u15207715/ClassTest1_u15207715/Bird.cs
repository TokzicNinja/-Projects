﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTest1_u15207715
{
    public class Bird:Animals
    {
        private int mAirspeed;

        public Bird(string inName, double inWeight, int inAmountLegs,int inAirSpeed)
            :base(inName,inWeight,inAmountLegs)
        {
            mAirspeed = inAirSpeed;
        }

        public override string DisplayInfo()
        {
            return base.DisplayInfo()+""+mAirspeed;
        }

        public override string Talk()
        {
            return "Birds sing";
        }
    }
}
