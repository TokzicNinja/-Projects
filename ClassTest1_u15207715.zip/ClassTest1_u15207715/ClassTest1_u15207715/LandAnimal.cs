﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTest1_u15207715
{
    public class LandAnimal:Animals 
    {
        private int LandSpeed;

        public LandAnimal(string inName, double inWeight, int inAmountLegs,int inLandSpeed) 
            :base(inName,inWeight,inAmountLegs)
        {
            LandSpeed = inLandSpeed;
        }

        public override string DisplayInfo()
        {
            return base.DisplayInfo() + "" + LandSpeed;
        }

        public override string Talk()
        {
            return "Depends on the type of land animal";
        }
    }
}
