﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaxiDriver;


namespace Extending_functionality
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.toolTip1.SetToolTip(newLabel,"This is the new the control that I have added new functionanlity to");
        }


        int x = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            extended_tools myLabel = new extended_tools();
            myLabel.getSet = new Ext_Label();

            if (x==imageList1.Images.Count)
            {
                x = 0;
            }
            else
            {
                pictureBox1.Image = imageList1.Images[x++];
                this.pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            }
        }
    }   
}
