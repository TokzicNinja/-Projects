﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaxiDriver;

namespace Extending_functionality
{
    class extended_tools:Label
    {
        public Ext_Label getSet//references the public Ext_Button// 
        { get; set; }
    }

    public class Ext_Label
    {
        public TaxiDriver.TaxiDriver driver { get; set; } = new TaxiDriver.TaxiDriver();
    }
}
