﻿namespace Extending_functionality
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.press_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.newLabel = new Extending_functionality.extended_tools();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // press_button
            // 
            resources.ApplyResources(this.press_button, "press_button");
            this.press_button.Name = "press_button";
            this.press_button.UseVisualStyleBackColor = true;
            this.press_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Image = global::Extending_functionality.Properties.Resources.game_05_jpg;
            this.pictureBox1.InitialImage = global::Extending_functionality.Properties.Resources.game_05_jpg;
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "4938_video_games.jpg");
            this.imageList1.Images.SetKeyName(1, "backgroundImage.img.jpg");
            this.imageList1.Images.SetKeyName(2, "call-of-duty-infinite-warfare-listing-thumb-01-ps4-us-08jun16.png");
            this.imageList1.Images.SetKeyName(3, "game-016.jpg");
            this.imageList1.Images.SetKeyName(4, "gamesIm.jpg");
            this.imageList1.Images.SetKeyName(5, "ghost recond wildlands square.jpg");
            this.imageList1.Images.SetKeyName(6, "mirrors_edge_catalyst_featured_game.jpg");
            this.imageList1.Images.SetKeyName(7, "SWTOR-966x423.jpg");
            this.imageList1.Images.SetKeyName(8, "wallpapers-game-10.jpg");
            // 
            // newLabel
            // 
            resources.ApplyResources(this.newLabel, "newLabel");
            this.newLabel.BackColor = System.Drawing.Color.Transparent;
            this.newLabel.ForeColor = System.Drawing.Color.Snow;
            this.newLabel.getSet = null;
            this.newLabel.Name = "newLabel";
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Extending_functionality.Properties.Resources.gamers_25;
            this.Controls.Add(this.newLabel);
            this.Controls.Add(this.press_button);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private TaxiDriver.TaxiDriver newDriver;
        public System.Windows.Forms.Button press_button;
        private System.Windows.Forms.ImageList imageList1;
        private extended_tools newLabel;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

