﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxiDriver
{
    public class TaxiDriver
    {
        private string mFirstName;
        private string mLastName;
        private string mMiddleName;
        private int mAge;
        private string mGender;
        private string mMaritalStatus;
        private int mHighestQualification;
        private bool mAttendedSchool;
        private bool mRace;
        private string mEthnicGroup;

        public TaxiDriver()
        {

        }

        public TaxiDriver(string mFirstName, string mLastName, string mMiddleName, int mAge, string mGender, string mMaritalStatus, int mHighestQualification, bool mAttendedSchool, bool mRace, string mEthnicGroup)
        {
            this.mFirstName = mFirstName;
            this.mLastName = mLastName;
            this.mMiddleName = mMiddleName;
            this.mAge = mAge;
            this.mGender = mGender;
            this.mMaritalStatus = mMaritalStatus;
            this.mHighestQualification = mHighestQualification;
            this.mAttendedSchool = mAttendedSchool;
            this.mRace = mRace;
            this.mEthnicGroup = mEthnicGroup;
        }

        public string FirstName
        {
            get{return mFirstName;}
            set{mFirstName = value;}
        }

        public string LastName
        {
            get{return mLastName;}
            set{mLastName = value;}
        }

        public string MiddleName
        {
            get{return mMiddleName;}
            set{ mMiddleName = value; }
        }

        public int Age
        {
            get{return mAge;}
            set {mAge = value;}
        }

        public string Gender
        {
            get{return mGender;}
            set{mGender = value;}
        }

        public string MaritalStatus
        {
            get{return mMaritalStatus;}
            set{mMaritalStatus = value;}
        }

        public int HighestQualification
        {
            get{return mHighestQualification;}
            set{mHighestQualification = value;}
        }

        public bool AttendedSchool
        {
            get{return mAttendedSchool;}
            set{mAttendedSchool = value;}
        }

        public bool Race
        {
            get{return mRace;}
            set{mRace = value;}
        }

        public string EthnicGroup
        {
            get{return mEthnicGroup;}
            set{mEthnicGroup = value;}
        }

        public virtual string JobType()
        {
            if(mAttendedSchool==true && (mHighestQualification>=8 && mHighestQualification<=12))
            {
                return "Needs a proper job";
            }
            else if(mAttendedSchool == true && (mHighestQualification >= 1 && mHighestQualification <= 7))
            {
                return "Receptionist,Cleaner,Gardner or Care Taker";
            }
            else
            {
                return "Just give him/her a taxi";
            }
        }

    }
}
