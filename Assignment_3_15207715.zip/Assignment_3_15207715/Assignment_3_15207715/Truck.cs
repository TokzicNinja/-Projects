﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_15207715
{
    public class Truck : Vehicle
    {
        private int mLoadCapacity;

        public int LoadCapacity
        {
            get { return mLoadCapacity; }
            set { mLoadCapacity = value; }
        }

        public Truck() : base() { }

        public Truck(string InEngineNum, int InEngineSize, string InMake, string InModel, string InVehicleReg,string InTypeOfField, int InLoadCapacity)
            : base(InEngineNum, InEngineSize, InMake, InModel, InVehicleReg,InTypeOfField)
        {
            mLoadCapacity = InLoadCapacity;
        }

        public string ToString(string inVehicleRegistration, int inEngineNumber, string inMake, string inModel, string inEngineSize, int inTypeOfField)
        {
            return "[TRUCK]: " + " " + inVehicleRegistration + " " + inEngineNumber + " " + inMake + " " + inModel + " " + inEngineSize + " " + inTypeOfField;
        }
    }
}
