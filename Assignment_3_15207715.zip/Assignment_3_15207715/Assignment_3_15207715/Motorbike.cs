﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_15207715
{
    public class Motorbike : Vehicle
    {
        private double mTopSpeed;

        public double TopSpeed
        {
            get { return mTopSpeed; }
            set { mTopSpeed = value; }
        }

        public Motorbike() : base() { }

        public Motorbike(string InEngineNum, int InEngineSize, string InMake, string InModel, string InVehicleReg,string InTypeOfField, double InTopSpeed)
            : base(InEngineNum, InEngineSize, InMake, InModel, InVehicleReg,InTypeOfField)
        {
            mTopSpeed = InTopSpeed;
        }

        public string ToString(string inVehicleRegistration, int inEngineNumber, string inMake, string inModel, string inEngineSize, double inTypeOfField)
        {

            return "[MOTORBIKE]: " + " " + inVehicleRegistration + " " + inEngineNumber + " " + inMake + " " + inModel + " " + inEngineSize + " " + inTypeOfField;
        }
    }
}
