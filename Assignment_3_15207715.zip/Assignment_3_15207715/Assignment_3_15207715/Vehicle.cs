﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_15207715
{
    public class Vehicle
    {
        private string mEngineNumber;
        private int mEngineSize;
        private string mMake;
        private string mModel;
        private string mVehicleRegistration;
        private string mTypeOfField;

        public Vehicle()
        {
            mEngineNumber ="";
            mEngineSize =0;
            mMake ="";
            mModel ="";
            mVehicleRegistration ="";
            mTypeOfField = "";
        }
        public Vehicle(string mEngineNumber, int mEngineSize, string mMake, string mModel, string mVehicleRegistration,string mTypeOfField)
        {
            this.EngineNumber = mEngineNumber;
            this.EngineSize = mEngineSize;
            this.Make = mMake;
            this.Model = mModel;
            this.VehicleRegistration = mVehicleRegistration;
            this.mTypeOfField = mTypeOfField; 
        }

        public string EngineNumber
        {
            get{return mEngineNumber;}
            set{mEngineNumber = value;}
        }

        public int EngineSize
        {
            get{return mEngineSize;}
            set{mEngineSize = value;}
        }

        public string Make
        {
            get{return mMake;}
            set{mMake = value;}
        }

        public string Model
        {
            get{return mModel;}
            set{mModel = value;}
        }

        public string VehicleRegistration
        {
            get{return mVehicleRegistration;}
            set{mVehicleRegistration = value;}
        }

        public string TypeOfField
        {   get { return mTypeOfField;}
            set { mTypeOfField = value;}
        }

        public virtual string ToString(string InEngineNumber, int InEngineSize, string InMake, string InModel, string InVehicleRegistration,string InTypeOfFieled)
        {
            return InEngineNumber + " " + InEngineSize + " " + InMake + " " + InModel + " " + InVehicleRegistration + " "+InTypeOfFieled;
        }
    }
}
