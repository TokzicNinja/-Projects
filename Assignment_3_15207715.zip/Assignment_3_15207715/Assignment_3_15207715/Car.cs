﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_15207715
{
    public class Car : Vehicle
    {
        private string mColour;

        public string Colour
        {
            get { return mColour; }
            set { mColour = value; }
        }

        public Car() : base() { }

        public Car(string InEngineNum, int InEngineSize, string InMake, string InModel, string InVehicleReg,string InTypeOfField, string InColour)
            : base(InEngineNum, InEngineSize, InMake, InModel, InVehicleReg,InTypeOfField)
        {
            mColour = InColour;
        }

        public override string ToString(string inVehicleRegistration,int inEngineNumber, string inMake, string inModel, string inEngineSize, string inTypeOfField)
        {
            return "[CAR]: " + " " + inVehicleRegistration + " " + inEngineNumber + " " + inMake + " " + inModel + " " + inEngineSize + " " + inTypeOfField;
        }
    }
}
