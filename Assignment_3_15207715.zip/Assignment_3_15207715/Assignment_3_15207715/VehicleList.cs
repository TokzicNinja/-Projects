﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Assignment_3_15207715
{
    public class VehicleList : BindingList<Vehicle>
    {

        List<Vehicle> sortedList;
        public void mySort(System.Windows.Forms.ListBox listBox, int size, VehicleList myData,Car myCar,Motorbike myMotorbike,Truck myTruck)
        {

            sortedList = (myData.Items.OrderBy(v => v.VehicleRegistration).ToList());

            listBox.Items.Clear();


            foreach ( var sort in sortedList)
            {
                if ((myCar == null)||(myTruck ==null)||(myMotorbike==null))
                {
                    myCar = new Car();
                    myMotorbike = new Motorbike();
                    myTruck = new Truck();
                }

                if (sort.GetType()==myCar.GetType())
                {
                    listBox.Items.Add("[CAR]: " + " " + sort.VehicleRegistration + " " + sort.EngineNumber + " " + sort.Make + " " + sort.Model + " " + sort.EngineSize + " " + sort.TypeOfField);
                }
                else if(sort.GetType()==myMotorbike.GetType())
                {
                    listBox.Items.Add("[MOTORBIKE]: " + " " + sort.VehicleRegistration + " " + sort.EngineNumber + " " + sort.Make + " " + sort.Model+" " + sort.EngineSize + " "+sort.TypeOfField );
                }
                else if(sort.GetType()==myTruck.GetType())
                {
                    listBox.Items.Add("[TRUCK]: " + " " + sort.VehicleRegistration + " " + sort.EngineNumber + " " + sort.Make + " " + sort.Model + " " + sort.EngineSize + " "+sort.TypeOfField);
                }
            }
        }
    }
}
