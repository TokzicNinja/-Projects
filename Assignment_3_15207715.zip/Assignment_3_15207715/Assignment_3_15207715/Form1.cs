﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_3_15207715
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        VehicleList myList = new VehicleList();

        Motorbike myMotorbike;
        Car myCar;
        Truck myTruck;
        string[] myListArr;

        int i = 0;
        int count = 0;
        string[] storeVehicleReg; 
        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            storeVehicleReg = new string[listBox1.Items.Count];

            if (cbxType.Text == "Motorbike")
            {
                myMotorbike = new Assignment_3_15207715.Motorbike();
                myMotorbike.VehicleRegistration = txtVehicleRegistration.Text;
                myMotorbike.EngineNumber = txtEngineNumber.Text;
                myMotorbike.Make = txtMake.Text;
                myMotorbike.Model = txtModel.Text;
                myMotorbike.EngineSize = Convert.ToInt32(txtEngineSize.Text);
                myMotorbike.TopSpeed = Convert.ToDouble(txtTypeOfField.Text);
                myMotorbike.TypeOfField = Convert.ToString(txtTypeOfField.Text);

                myList.Add(myMotorbike);
                i++;


                myListArr = new string[i];

                
                foreach (string values in listBox1.Items)
                {
                    myListArr[count] = values;
                }

                lblTypeOfField.Text = "Top Speed";
                listBox1.Items.Add(myMotorbike.ToString(txtVehicleRegistration.Text, Convert.ToInt32(txtEngineNumber.Text), txtMake.Text, txtModel.Text, txtEngineSize.Text, Convert.ToDouble(txtTypeOfField.Text)));
                listBox1.Refresh();
            }
            else if (cbxType.Text == "Car")
            {
                myCar = new Assignment_3_15207715.Car();
                myCar.VehicleRegistration = txtVehicleRegistration.Text;
                myCar.EngineNumber = txtEngineNumber.Text;
                myCar.Make = txtMake.Text;
                myCar.Model = txtModel.Text;
                myCar.EngineSize = Convert.ToInt32(txtEngineSize.Text);
                myCar.Colour = Convert.ToString(txtTypeOfField.Text);
                myCar.TypeOfField = (string)txtTypeOfField.Text;

                myList.Add(myCar);
                i++;


                myListArr = new string[i];

                foreach (string values in listBox1.Items)
                {
                    myListArr[count] = values;
                }

                lblTypeOfField.Text = "Colour";
                listBox1.Items.Add(myCar.ToString(txtVehicleRegistration.Text, Convert.ToInt32(txtEngineNumber.Text), txtMake.Text, txtModel.Text, txtEngineSize.Text, txtTypeOfField.Text));
                listBox1.Refresh();
            }
            else if (cbxType.Text == "Truck")
            {
                myTruck = new Assignment_3_15207715.Truck();
                myTruck.VehicleRegistration = txtVehicleRegistration.Text;
                myTruck.EngineNumber = txtEngineNumber.Text;
                myTruck.Make = txtMake.Text;
                myTruck.Model = txtModel.Text;
                myTruck.EngineSize = Convert.ToInt32(txtEngineSize.Text);
                myTruck.LoadCapacity = Convert.ToInt32(txtTypeOfField.Text);
                myTruck.TypeOfField = (string)txtTypeOfField.Text;

                myList.Add(myTruck);
                i++;

                myListArr = new string[i];

                foreach (string values in listBox1.Items)
                {
                    myListArr[count] = values;
                }

                lblTypeOfField.Text = "Load Capacity";
                listBox1.Items.Add(myTruck.ToString(txtVehicleRegistration.Text, Convert.ToInt32(txtEngineNumber.Text), txtMake.Text, txtModel.Text, txtEngineSize.Text, Convert.ToInt32(txtTypeOfField.Text)));
            }
            count++;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Refresh();

            if (cbxType.SelectedText == "Motorbike")
            {
                lblTypeOfField.Text = "Top Speed";

                this.Refresh();
            }
            else if (cbxType.SelectedText == "Car")
            {
                lblTypeOfField.Text = "Colour";
                this.Refresh();
            }
            else if (cbxType.SelectedText == "Truck")
            {
                lblTypeOfField.Text = "Load Capacity";
                this.Refresh();
            }
            else
            {
                lblTypeOfField.Text = "Waiting...";
                this.Refresh();
            }
        }

        public void SelectedValue()
        {
            if (cbxType.SelectedText == "Motorbike")
            {
                timer1.Enabled = true;
                lblTypeOfField.Text = "Top Speed";
                txtTypeOfField.Text = Convert.ToString(myMotorbike.TopSpeed);
                this.Refresh();
            }
            else if (cbxType.SelectedText == "Car")
            {
                timer1.Enabled = true;
                timer1.Start();
                lblTypeOfField.Text = "Colour";
                txtTypeOfField.Text = Convert.ToString(myCar.Colour);
                this.Refresh();
            }
            else if (cbxType.SelectedText == "Truck")
            {
                timer1.Enabled = true;
                timer1.Start();
                lblTypeOfField.Text = "Load Capacity";
                txtTypeOfField.Text = Convert.ToString(myTruck.LoadCapacity);
                this.Refresh();
            }
            else
            {
                timer1.Enabled = false;
                timer1.Start();
                lblTypeOfField.Text = "Waiting...";
            }

            listBox1.Refresh();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            myList.mySort(listBox1,i,myList,myCar,myMotorbike,myTruck);
            listBox1.Refresh();
        }

        int z = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
                if(z==100)
                {
                    lblNote.Visible = false;
                z = 0;
                 }
                if(z==50)
            {
                lblNote.Visible = true;
            }
                z++;
        }
        
    }
}
